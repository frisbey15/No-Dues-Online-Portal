<?php
	$username=$_POST["user"];
	$password=$_POST["pass"];

	$username=stripslashes($username);
	$password=stripslashes($password);

	//$username=mysql_real_escape_string($username);
	//$password==mysql_real_escape_string($password);

	$mysql_host="localhost";
	$mysql_user="root";
	$mysql_password='';
	$db=mysql_select_db("login");
	if(!mysql_connect($mysql_host,$mysql_user,$mysql_password)||!mysql_select_db("login")){
		die(mysql_error());
	}
	//$query=;
	if($result=mysql_query("SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'") or die(mysql_error())){
		$n=mysql_num_rows($result);
		//echo 'n is'.$result;
		if($n!=0){
			echo 'valid';
		}else{
			echo 'invalid';
		}
	}

	//$row=mysql_fetch_array($result) or die("failed fetch".mysql_error());


	//if($row['username']== $username && $row['password']== $password){
	//	echo 'LOGIN SUCCESS';
	//}
	//else{
	//	echo $row['username'];
	//	echo 'failed';
	//}


?>
